window.addEventListener('scroll', function() {
    var sectionButton = document.getElementById('sectionButton');
    if (window.scrollY > 850) { // Adjust the value as needed
        sectionButton.style.display = 'none';
    } else {
        sectionButton.style.display = 'block';
    }
});

document.getElementById('sectionButton').addEventListener('click', function(e) {
    e.preventDefault();
    var targetSection = document.getElementById('Leistungen');
    targetSection.scrollIntoView({ behavior: 'smooth' });
});

function myFunction() {
    var x = document.getElementById("mynavbar");
    if (x.className === "navbar") {
        x.className += " responsive";
    } else {
        x.className = "navbar";
    }
} 